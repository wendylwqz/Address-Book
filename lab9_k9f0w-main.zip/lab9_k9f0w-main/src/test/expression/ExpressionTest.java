package expression;

import expression.exception.ExpressionNotValidException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

class ExpressionTest {
    @Test
    void testValueToString() {
        Value x = new Value(1);
        assertEquals("1", x.toString());
    }

    @Test
    void testabstract() {
        AdditionExpression ae = new AdditionExpression();
        ae.addSubexpression(new Value(2));
        ae.addSubexpression(new Value(-3));
        ae.addSubexpression(new Value(1));
        assertEquals(0, ae.getValue());

        SubtractionExpression se = new SubtractionExpression();
        se.addSubexpression(new Value(2));
        se.addSubexpression(new Value(-3));
        se.addSubexpression(new Value(1));
        assertEquals(4, se.getValue());

        MultiplicationExpression me = new MultiplicationExpression();
        me.addSubexpression(new Value(2));
        me.addSubexpression(new Value(-3));
        me.addSubexpression(new Value(1));
        assertEquals(-6, me.getValue());

        DivisionExpression de = new DivisionExpression();
        de.addSubexpression(new Value(4));
        de.addSubexpression(new Value(-3));
        de.addSubexpression(new Value(1));
        assertEquals(-1, de.getValue());
        assertEquals("(/ 4 -3 1)", de.toString());

        AdditionExpression adme = ae;
        adme.addSubexpression(de);
        adme.addSubexpression(me);
        assertEquals(-7, adme.getValue());

        AdditionExpression ame = new AdditionExpression();
        ame.addSubexpression(ae);
        ame.addSubexpression(me);
        assertEquals(-13, ame.getValue());

        DivisionExpression div = new DivisionExpression();
        div.addSubexpression(new Value(9));
        div.addSubexpression(new Value(3));    // (/ 9 3)
        assertEquals(3, div.getValue());

        AdditionExpression add = new AdditionExpression();
        add.addSubexpression(new Value(3));
        add.addSubexpression(div);             // (+ 3 (/ 9 3))
        assertEquals(6, add.getValue());

        SubtractionExpression sub = new SubtractionExpression();
        sub.addSubexpression(new Value(9));
        sub.addSubexpression(new Value(4));    // (- 9 4)
        assertEquals(5, sub.getValue());

        MultiplicationExpression mult = new MultiplicationExpression();
        mult.addSubexpression(new Value(2));
        mult.addSubexpression(sub);
        mult.addSubexpression(add);            // (* 2 (- 9 4) (+ 3 (/ 9 3)))
        assertEquals(60, mult.getValue());

        String toString = mult.toString();
        assertEquals("(* 2 (- 9 4) (+ 3 (/ 9 3))) evaluates to 60",
                toString + " evaluates to " + mult.getValue());
    }

    @Test
    void testUnsupportedException() {
        DivisionExpression dNotValid = new DivisionExpression();
        dNotValid.addSubexpression(new Value(2));
        dNotValid.addSubexpression(new Value(0));
        try {
            dNotValid.getValue();
            fail();
        } catch (ExpressionNotValidException e) {
            fail();
        } catch (UnsupportedOperationException e) {
            //ye
        }
    }

    @Test
    void testExpressionNotValid() {
        AdditionExpression ab = new AdditionExpression();
        try {
            ab.getValue();
            fail();
        } catch (ExpressionNotValidException e) {
            // ye
        } catch (UnsupportedOperationException e) {
            fail();
        }
        assertEquals("!!! (+)", ab.toString());
        ab.addSubexpression(new Value(2));
        try {
            ab.getValue();
            fail();
        } catch (ExpressionNotValidException e) {
            // ye
        } catch (UnsupportedOperationException e) {
            fail();
        }
        assertEquals("!!! (+ 2)", ab.toString());
    }
}