package expression;

import java.util.ArrayList;
import java.util.List;

public class MultiplicationExpression extends AbstractArithmeticExpression {
    List<Expression> multis = new ArrayList<>();

    public MultiplicationExpression() {
        super("*");
    }

    // TODO: complete implementation
}
