package expression;

import java.util.ArrayList;
import java.util.List;

public class DivisionExpression extends AbstractArithmeticExpression {
    List<Expression> divs = new ArrayList<>();

    public DivisionExpression() {
        super("/");
    }

    // TODO: complete implementation
}
