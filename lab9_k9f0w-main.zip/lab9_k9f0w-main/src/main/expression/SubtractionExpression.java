package expression;

import java.util.ArrayList;
import java.util.List;

public class SubtractionExpression extends AbstractArithmeticExpression {
    List<Expression> subs = new ArrayList<>();

    public SubtractionExpression() {
        super("-");
    }

    // TODO: complete implementation
}
