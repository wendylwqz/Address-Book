package expression;

import expression.exception.ExpressionNotValidException;

import java.util.ArrayList;
import java.util.List;

// Represents an expression having an operand and an arbitrary
// number of subexpressions and/or values
public abstract class AbstractArithmeticExpression implements Expression {
    List<Expression> expressions;
    String operator;

    // EFFECTS: constructs an expression with given operator having no sub-expressions or values
    public AbstractArithmeticExpression(String op) {
        operator = op;
        this.expressions = new ArrayList<>();
    }

    @Override
    public int getValue() throws ExpressionNotValidException, UnsupportedOperationException {
        ArrayList<Integer> x = new ArrayList<>();
        if (expressions.size() < 2) {
            throw new ExpressionNotValidException();
        }
        for (Expression aae : expressions) {
            x.add(aae.getValue());
        }

        if (operator == "+") {
            return plus(x);
        } else if (operator == "-") {
            return minus(x);
        } else if (operator == "*") {
            return multiply(x);
        }
        return divide(x);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        addop(sb);
        for (Expression e : expressions) {
            String ee = e.toString();
            sb.append(" " + ee);
        }
        sb.append(")");

        return finalToString(sb);
    }

    public String finalToString(StringBuilder sb) {
        if (expressions.size() < 2) {
            return sb.insert(0, "!!! ").toString();
        } else {
            return sb.toString();
        }
    }

    public StringBuilder addop(StringBuilder sb) {
        if (operator == "+") {
            sb.append("(+");
        } else if (operator == "-") {
            sb.append("(-");
        } else if (operator == "/") {
            sb.append("(/");
        } else {
            sb.append("(*");
        }
        return sb;
    }

    public void addSubexpression(Expression e) {
        expressions.add(e);
    }

    public int plus(ArrayList<Integer> x) {
        int rsf = 0;
        for (int e : x) {
            rsf += e;
        }
        return rsf;
    }

    public int minus(ArrayList<Integer> x) {
        int rsf = x.remove(0);
        for (int e : x) {
            rsf -= e;
        }
        return rsf;
    }

    public int divide(ArrayList<Integer> x) throws UnsupportedOperationException {
        int rsf = x.remove(0);
        for (int e : x) {
            if (e == 0) {
                throw new UnsupportedOperationException();
            }
            rsf = rsf / e;
        }
        return rsf;
    }

    public int multiply(ArrayList<Integer> x) {
        int rsf = x.remove(0);
        for (int e : x) {
            rsf =  e * rsf;
        }
        return rsf;
    }
}
