package expression;

import java.util.ArrayList;
import java.util.List;

public class AdditionExpression extends AbstractArithmeticExpression {

    public AdditionExpression() {
        super("+");
    }

    // TODO: complete implementation
}
