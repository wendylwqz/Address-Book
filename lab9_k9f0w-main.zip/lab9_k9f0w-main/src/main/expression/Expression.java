package expression;

public interface Expression {
    // EFFECTS: returns value of expression
    // throws ExpressionNotValidException if expression does not have at least two sub-expressions
    // throws UnsupportedOperationException if division by zero occurs
    int getValue();


    @Override
    // EFFECTS: returns string representation of expression
    // prepends "!!! " in cases where the expression does not have at least two sub-expressions
    String toString();
}
